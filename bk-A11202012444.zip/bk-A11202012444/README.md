1. git clone dari repository
2. buka terminal pada folder yang diclone
3. pada terminal lakukan 'composer update'
4. file .env.example copy dan ganti namanya jadi .env
5. nyalakan xampp (apache dan mysql), atau gunakan alternatif tool database lainnya
6. pada terminal lakukan 'php artisan key:generate'
7. pada terminal lakukan 'php artisan db:seed role'
8. jalankan dengan perintah 'php artisan serve' pada terminal